package com.javamastermind.com.sms.util;

import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class StudentControllerAdvisor {


}
