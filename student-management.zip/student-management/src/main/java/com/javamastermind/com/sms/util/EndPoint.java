package com.javamastermind.com.sms.util;

public class EndPoint {
	public static final String GETSTUDENT = "/v1/getAllStudents";
	public static final String SAVESTUDENT = "/v1/saveStudent";
	public static final String UPDATESTUDENT = "/v1/updateStudent";
	public static final String FINDSTUDENT = "/v1/findStudent";
	public static final String DELETESTUDENT =  "/v1/deleteStudent";
}

